﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using json = Newtonsoft.Json;
using jser = Newtonsoft.Json.Serialization;
using jsu = Newtonsoft.Json.Utilities;
using jarray = Newtonsoft.Json.Linq;
using CensusApi.Entities;

namespace CensusApi.Utilities
{
    /// <summary>
    /// Summary description for ApiUtilities
    /// </summary>
    public static class ApiUtilities
    {

        public static IList<Field> Results { get; private set; }

        public static void ReadJsonQueryResults(ref json.JsonReader reader)
        {
            jarray.JArray jray = new jarray.JArray();
            string value = string.Empty;           

            //Add each value into a JArray
            using (reader)
            {
                while (reader.Read())
                {
                    //Check if we are at the end of the single result array
                    if (reader.TokenType != json.JsonToken.EndArray && reader.Value != null)
                    {                       
                        //Note: Although http://www.census.gov/developers/ says the JSON result set is a 2 dimension query, where 
                        //the top row contains the field names, the JSON.NET reader flattents it to a 1-dim array (as you'll
                        //see from the results stored in the "value" string. We'll have to modify the domain model to take
                        //this into account...see domain model "JsonData"
                        value = reader.Value.ToString();                        
                        jray.Add(value);                      
                    }
                }

                reader.Close();
            }

            //----- DBUG ----------
            value = jray.ToString();

            JsonData jdata = new JsonData();
            jdata.PopulateResultSet(jray);
            Results = jdata.ResultSet;
        }

        public static string SerializeToJson<T>(IList<T> args) where T:IEntity
        {
            string rslt = string.Empty;
            rslt = json.JsonConvert.SerializeObject(args); //HOWEVER, this won't be format of Census API.  This is for future use
            return rslt;
        }
    }

}