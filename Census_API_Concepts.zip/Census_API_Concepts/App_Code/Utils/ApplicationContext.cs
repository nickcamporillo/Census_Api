﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using iut = IST.Utilities;

namespace CensusApi.Utilities
{
    /// <summary>
    /// Summary description for ApplicationContext
    /// </summary>
    public static class ApplicationContext
    {
        
    }
}