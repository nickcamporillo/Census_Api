﻿using System;
using System.Text;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Web.UI;
using System.Web.UI.WebControls;
using json = Newtonsoft.Json;
using jser = Newtonsoft.Json.Serialization;
using jsu = Newtonsoft.Json.Utilities;
using jarray = Newtonsoft.Json.Linq;

/// <summary>
/// Summary description for basePage
/// </summary>
public class BasePage : System.Web.UI.Page
{
    //Sample query strings:
    //http://api.census.gov/data/2010/sf1?key=a8e19a47c9c91ffa82c63c0f383ebbe8d7b3fa55&get=PCT012A015,PCT012A119&for=state:01,02,03,04
    //http://api.census.gov/data/2010/sf1?key=a8e19a47c9c91ffa82c63c0f383ebbe8d7b3fa55&get=P0030005,NAME&for=state:*
    //

    protected const string API_WEBSITE = "http://www.census.gov/developers/"; //Go here for documentation if you ever need it.
    protected const string API_NEWSGROUP = "http://apiforum.ideascale.com/"; //The Census API newsgroup. Go here to see what people are doing with the API


    //----------------------------------------------------------------------------
    //------------------------ Query Strings for API -----------------------------
    //----------------------------------------------------------------------------
    protected const string SF1_REQUEST = "http://api.census.gov/data/2010/sf1?key=";
    protected const string API_KEY = "a8e19a47c9c91ffa82c63c0f383ebbe8d7b3fa55";

    
    //----------------------------------------------------------------------------
    //------------------------- HTTP Error Messages ------------------------------
    //----------------------------------------------------------------------------
    //200: Indicates success. The response body will contain a JSON array as described above.
    //204: Indicates the request succeeded but no records matched your query.
    //400: Indicates that the request was not valid. Examples include queries for unknown 
    //     variables or unknown geographies. A message describing the error will be included 
    //     in the response body.
    //500: Indicates that there was a server-side error while processing the request. 
    //     Please wait a few minutes and try your query again.
    protected string HTTP_MSG_SUCCESS = "200";
    protected string HTTP_MSG_SUCCESS_NO_RESULTS = "204";
    protected string HTTP_MSG_INVALID_REQUEST = "400";
    protected string HTTP_MSG_SERVER_ERROR = "500";

    public BasePage()
    {
        
    }


    protected string CreateQueryString(string field_names,string query_string2,string county_fips_code, string state_fips_code)
    {

        //Test datafield: "PCT0050008" (filipinos for App "Pinoy Pinder")

        string FIELD_ID = field_names; //"P0010001";// **Note: Items "P0010002"; thru 2000 series throw the HTTP_MSG_INVALID_REQUEST exception; probably those fields don't exist

        //string GET_STRING = "&get=" + FIELD_ID + ",NAME&for=state:*";            
        //string GET_STRING = "&get=" + FIELD_ID + "," + DatasourceFieldId_2.SelectedValue + "&for=state:*";            
        //string GET_STRING = "&get=" + FIELD_ID + "," + DatasourceFieldId_2.SelectedValue + "&for=state:" + txtStateFipsCodes.Text.Trim();

        //string GET_STRING =
        //    (FIELD_ID != query_string2 ? "&get=" + FIELD_ID + "," + field_names + ",NAME&for=county:" + county_fips_code.Trim() + "&in=state:" + state_fips_code.Trim()
        //     : "&get=" + FIELD_ID + ",NAME&for=county:" + county_fips_code.Trim() + "&in=state:" + state_fips_code.Trim());


        string GET_STRING =
            (FIELD_ID = "&get=" + FIELD_ID + ",NAME&for=county:" + county_fips_code.Trim() + "&in=state:" + state_fips_code.Trim());

        string full_query = SF1_REQUEST + API_KEY + GET_STRING;


        return full_query;
    }

    protected System.Net.WebResponse _response = null;
    protected Stream GetResponseStream(string query_string)
    { 
        Stream stream = null;
        System.Net.HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(query_string);
        string debug = string.Empty;
            
        request.ContentType = "application/json; charset=utf-8";
        request.Accept = "application/json, text/javascript, */*";
        request.Method = "GET";

        try
        {
            _response = request.GetResponse();
            stream = _response.GetResponseStream();
        }
        catch (Exception ex)
        {
            debug = "Error " + HTTP_MSG_INVALID_REQUEST + "\n\n" + ex.Message;
        }

        return stream;    
    }

    protected void CloseStreams()
    {
        if (_response != null)
            _response.Close();
        _response = null;
    }

    protected string GetDataDirectoryPath()
    {
        return HttpRuntime.AppDomainAppPath + @"App_Data\";
    }

}