﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace CensusApi.Entities
{
	/// <summary>
	/// Summary description for GeoItem
	/// </summary>
	public class GeoItem: IEntity
	{
        public string FIPS { get; private set; }
        public string StateFIPS { get; private set; }
        public string CountyFIPS { get; private set; }
        public string County { get; private set; }
        public string StateName { get; private set; }

		public GeoItem() { }

        public void SetFips(string data_line)
        {
            char[] tChar = { ',', ' ' };
            string[] tStr;
            tStr = null;
            tStr = data_line.Split(tChar);
            this.FIPS = tStr[0];
            this.StateFIPS = tStr[0].Substring(0,2);
            this.CountyFIPS = tStr[0].Substring(2, 3);
            this.County = tStr[1] + (tStr.Length >= 3 ? " " + tStr[2] : "");
            this.StateName = (tStr.Length == 5 ? tStr[4] : "");                    
        }

	}

    public class GeoItems
    {        

        public IList<GeoItem> Items { get; set; }

        public GeoItems()
        {
            Items = new List<GeoItem>();        
        }

        public void ReadFipsFile(string filePathName)
        {
            //Is there an IST utility for this? The following snipped fromhttp: http://msdn.microsoft.com/en-us/library/ezwyzy7b.aspx

            string[] lines = System.IO.File.ReadAllLines(filePathName);

            // Display the file contents by using a foreach loop.
            foreach (string line in lines)
            {
                GeoItem itm = new GeoItem();
                itm.SetFips(line);
                Items.Add(itm);
            }
        }

    }
}