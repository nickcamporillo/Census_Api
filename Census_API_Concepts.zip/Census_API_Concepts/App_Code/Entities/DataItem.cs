﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DataItem
/// </summary>
public class DataItem
{

	private string _data = string.Empty;
	private string _fips = string.Empty;


	public string Data { get; set; }
	public string FIPS { get; set; }

	public DataItem(string data, string fips)
	{
		Data = data;
		FIPS = fips;
	}
}