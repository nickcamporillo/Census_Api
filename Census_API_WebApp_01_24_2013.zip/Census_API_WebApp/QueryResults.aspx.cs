﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CensusApi.Entities;

public partial class QueryResults : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        IList<Field> f = base.GetJsonQueryFromSession() as IList<Field>;
        var county_name = f.Where(c => c.Name.ToUpper() == "NAME");
        var state_name = f.Where(c => c.Name.ToUpper() == "STATE");
        var county_code = f.Where(c => c.Name.ToUpper() == "COUNTY");

        grdResults.DataSource = null;

        grdResults.DataSource = base.GetJsonQueryFromSession();
        grdResults.DataBind();

        DataItem di = new DataItem();

        IList<GeoItem> fips_items;


    }

}