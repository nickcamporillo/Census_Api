﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for IConcept
/// </summary>
namespace CensusApi.Entities
{
    public interface IConcept:IEntity
    {
        int Count { get; }
        IList<Variable> VariableList {get;}

        IList<Variable> FetchConcepts();
        IList<Variable> FetchConceptsByDescription(string description_string);
    }
}