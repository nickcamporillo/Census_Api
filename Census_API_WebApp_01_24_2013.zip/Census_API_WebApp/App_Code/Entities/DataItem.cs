﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DataItem
/// </summary>
namespace CensusApi.Entities
{
    public class DataItem : IEntity
    {
        public GeoItem FIPS { get; set; }
        public Dataset Dataset { get; set; }

        public DataItem() { }

        public DataItem(GeoItem fips, Dataset dataset)
        {
            FIPS = fips;
            Dataset = dataset;
        }

    }
}