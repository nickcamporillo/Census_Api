﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Dataset
/// </summary>
namespace CensusApi.Entities
{
    public class Dataset:IEntity
    {
        public string DataSet { get; set; }
        public string Value { get; set; }
    }
}