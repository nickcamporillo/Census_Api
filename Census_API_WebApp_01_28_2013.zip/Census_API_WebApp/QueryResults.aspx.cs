﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using CensusApi.Entities;

public partial class QueryResults : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Concepts concs = new Concepts(base.GetDataDirectoryPath() + CONCEPT_METADATA_FILE);
        concs.FetchConcepts();


        Dataset dis = new Dataset(concs);        

        grdPreProcess.DataSource = base.GetJsonQueryFromSession();
        grdPreProcess.DataBind();

        dis.CreateDataset(base.GetJsonQueryFromSession() as IList<Field>);
        grdResults.DataSource = dis.Results;
        grdResults.DataBind();
    }

}