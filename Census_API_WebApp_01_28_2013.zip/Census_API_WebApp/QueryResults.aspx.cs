﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using CensusApi.Entities;

public partial class QueryResults : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
   
        //IList<Field> f = base.GetJsonQueryFromSession() as IList<Field>;
        Dataset dis = new Dataset();
        dis.CreateDataset(base.GetJsonQueryFromSession() as IList<Field>);

        grdPreProcess.DataSource = base.GetJsonQueryFromSession();
        grdPreProcess.DataBind();
                
        grdResults.DataSource = dis.Results;
        grdResults.DataBind();
    }

}