﻿using System;
using System.Text;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Web.UI;
using System.Web.UI.WebControls;
using json = Newtonsoft.Json;
using jser = Newtonsoft.Json.Serialization;
using jsu = Newtonsoft.Json.Utilities;
using jarray = Newtonsoft.Json.Linq;

/// <summary>
/// Summary description for basePage
/// </summary>
public class BasePage : System.Web.UI.Page
{
    
    //----------------------------------------------------------------------------
    //------------------------- HTTP Error Messages ------------------------------
    //----------------------------------------------------------------------------
    //200: Indicates success. The response body will contain a JSON array as described above.
    //204: Indicates the request succeeded but no records matched your query.
    //400: Indicates that the request was not valid. Examples include queries for unknown 
    //     variables or unknown geographies. A message describing the error will be included 
    //     in the response body.
    //500: Indicates that there was a server-side error while processing the request. 
    //     Please wait a few minutes and try your query again.
    protected const string HTTP_MSG_SUCCESS = "200";
    protected const string HTTP_MSG_SUCCESS_NO_RESULTS = "204";
    protected const string HTTP_MSG_INVALID_REQUEST = "400";
    protected const string HTTP_MSG_SERVER_ERROR = "500";

    protected const string API_FIELD_STATECODE = "STATE";
    protected const string API_FIELD_COUNTYCODE = "COUNTY";
    protected const string API_FIELD_COUNTYNAME = "NAME";

    protected const string CONCEPT_METADATA_FILE = "apivariables.xml";

    public BasePage()
    {
        
    }

    protected System.Net.WebResponse _response = null;
    protected Stream GetJsonResponseStream(string query_string)
    { 
        Stream stream = null;
        System.Net.HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(query_string);
        string debug = string.Empty;
            
        request.ContentType = "application/json; charset=utf-8";
        request.Accept = "application/json, text/javascript, */*";
        request.Method = "GET";

        try
        {
            _response = request.GetResponse();
            stream = _response.GetResponseStream();
        }
        catch (Exception ex)
        {
            debug = "Error " + HTTP_MSG_INVALID_REQUEST + "\n\n" + ex.Message;
        }

        return stream;    
    }

    protected void CloseStreams()
    {
        if (_response != null)
            _response.Close();
        _response = null;
    }

    protected void SetJsonQueryToSession(object json_query)
    {
        if (Session["JSON_RESULTS"] != null)
            Session["JSON_RESULTS"] = json_query;
        else
            Session.Add("JSON_RESULTS", json_query);
    }

    protected object GetJsonQueryFromSession()
    {
        if (Session["JSON_RESULTS"] != null)
            return Session["JSON_RESULTS"];
        else
            return null;
    }

    protected string GetDataDirectoryPath()
    {
        return HttpRuntime.AppDomainAppPath + @"App_Data\";
    }

}