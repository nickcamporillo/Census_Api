﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Web;
using System.Net;
using System.Web.UI;
using System.Web.UI.WebControls;

using json = Newtonsoft.Json;
using jser = Newtonsoft.Json.Serialization;
using jsu = Newtonsoft.Json.Utilities;
using jarray = Newtonsoft.Json.Linq;
using CensusApi.Entities;

namespace CensusApi.Utilities
{
    /// <summary>
    /// Summary description for ApiUtilities
    /// </summary>
    public static class ApiUtilities
    {
        //Sample query strings:
        //http://api.census.gov/data/2010/sf1?key=a8e19a47c9c91ffa82c63c0f383ebbe8d7b3fa55&get=PCT012A015,PCT012A119&for=state:01,02,03,04
        //http://api.census.gov/data/2010/sf1?key=a8e19a47c9c91ffa82c63c0f383ebbe8d7b3fa55&get=P0030005,NAME&for=state:*
        //

        private const string API_WEBSITE = "http://www.census.gov/developers/"; //Go here for documentation if you ever need it.
        private const string API_NEWSGROUP = "http://apiforum.ideascale.com/"; //The Census API newsgroup. Go here to see what people are doing with the API

        //----------------------------------------------------------------------------
        //------------------------ Query Strings for API -----------------------------
        //----------------------------------------------------------------------------
        private const string SF1_REQUEST = "http://api.census.gov/data/2010/sf1?key=";
        private const string API_KEY = "a8e19a47c9c91ffa82c63c0f383ebbe8d7b3fa55";

        //----------------------------------------------------------------------------
        //------------------------- HTTP Error Messages ------------------------------
        //----------------------------------------------------------------------------
        //200: Indicates success. The response body will contain a JSON array as described above.
        //204: Indicates the request succeeded but no records matched your query.
        //400: Indicates that the request was not valid. Examples include queries for unknown 
        //     variables or unknown geographies. A message describing the error will be included 
        //     in the response body.
        //500: Indicates that there was a server-side error while processing the request. 
        //     Please wait a few minutes and try your query again.
        private const string HTTP_MSG_SUCCESS = "200";
        private const string HTTP_MSG_SUCCESS_NO_RESULTS = "204";
        private const string HTTP_MSG_INVALID_REQUEST = "400";
        private const string HTTP_MSG_SERVER_ERROR = "500";
        
        private static WebResponse _response = null;

        public static Stream GetJsonResponseStream(string query_string)
        {
            Stream stream = null;
            System.Net.HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(query_string);
            string debug = string.Empty;

            request.ContentType = "application/json; charset=utf-8";
            request.Accept = "application/json, text/javascript, */*";
            request.Method = "GET";

            try
            {
                _response = request.GetResponse();
                stream = _response.GetResponseStream();
            }
            catch (Exception ex)
            {
                debug = "Error " + HTTP_MSG_INVALID_REQUEST + "\n\n" + ex.Message;
            }

            return stream;
        }

        private static string GetApiKey()
        {  
            return CensusApiConfiguration.GetConfig().Settings["api_key"].Value;
        }

        public static string CreateQueryString(string field_names, string county_fips_code, string state_fips_code)
        {
            //"Guard" strings. An empty value will throw an exception when the JSON query is submitted.
            string state_fips = (state_fips_code == null || state_fips_code.Length == 0 ? "*" : state_fips_code);
            string county_fips = (county_fips_code == null || county_fips_code.Length == 0 ? "*" : county_fips_code);

            if (field_names == null || field_names.Trim().Length == 0)
                throw new Exception("Dataset name must be provided");

            string FIELD_ID = field_names; //"P0010001";// **Note: Items "P0010002"; thru 2000 series throw the HTTP_MSG_INVALID_REQUEST exception; probably those fields don't exist

            string full_query = string.Empty;
            string[] splitted = state_fips_code.Split(',');
            int state_count = splitted.Length;

            //Use the GET_STRING_1 if you have multiple states - doesn't seem you can do both multiple states and multiple 
            //counties at the same time.  Otherwise, use GET_STRING_2.
            string GET_STRING_1 = "&get=" + FIELD_ID + ",NAME&for=county:" + county_fips.Trim() + "&in=state:" + state_fips.Trim();
            string GET_STRING_2 = "&get=" + FIELD_ID + ",NAME&for=state:" + state_fips.Trim();
            string GET_STRING = (state_count == 1 ? GET_STRING_1 : GET_STRING_2);
            
            full_query = SF1_REQUEST + GetApiKey() + GET_STRING;

            return full_query;

        }

        public static IList<Field> Results { get; private set; }

        public static void ReadJsonQueryResults(Stream stream)
        {
            //Look here to deserialize 2 dimensonal array, which is the type of JSON
            //you get from the API: http://json.codeplex.com/discussions/352208/                
            json.JsonReader reader = new json.JsonTextReader(new StreamReader(stream));

            jarray.JArray jray = new jarray.JArray();
            string value = string.Empty;           

            //Add each value into a JArray
            using (reader)
            {
                while (reader.Read())
                {
                    //Check if we are at the end of the single result array
                    if (reader.TokenType != json.JsonToken.EndArray && reader.Value != null)
                    {                       
                        //Note: Although http://www.census.gov/developers/ says the JSON result set is a 2 dimension query, where 
                        //the top row contains the field names, the JSON.NET reader flattents it to a 1-dim array (as you'll
                        //see from the results stored in the "value" string. We'll have to modify the domain model to take
                        //this into account...see domain model "JsonData"
                        value = reader.Value.ToString();                        
                        jray.Add(value);                      
                    }
                }

                reader.Close();
            }

            //----- DBUG ----------
            value = jray.ToString();

            JsonData jdata = new JsonData();
            jdata.PopulateResultSet(jray);
            Results = jdata.ResultSet;
        }

        public static string SerializeToJson<T>(IList<T> args) where T:IEntity
        {
            string rslt = string.Empty;
            rslt = json.JsonConvert.SerializeObject(args); //HOWEVER, this won't be format of Census API.  This is for future use
            return rslt;
        }
    }

}