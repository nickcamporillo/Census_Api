﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Field
/// </summary>
namespace CensusApi.Entities
{
    public class Field : IEntity
    {
        private string _name = string.Empty;
        public int Id { get; set; }
       
        public string Name 
        {
            get { return _name.ToUpper(); }                 
            set { _name = value.ToUpper(); }
        }        

        public string Value { get; set; }
    }
}