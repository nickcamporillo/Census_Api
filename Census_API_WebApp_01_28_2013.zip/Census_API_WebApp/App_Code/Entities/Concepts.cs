﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace CensusApi.Entities
{

    /// <summary>
    /// Summary description for Concepts
    /// </summary>
    public class Concepts : IConcept
    {
        private Sf1VariableList meta = new Sf1VariableList();

        //NOTE: Even though the Interface says Concepts is a readonly get{} property, you are  
        //still able to create a **private set{} !!!!!!!!!!!!!!!!!!! This is very useful!!!!!
        public IList<Variable> VariableList
        {
            get {return meta.VariableList;}
            private set{;}
        }

        public int Count
        {
            get { return VariableList.Count; }
        }

        public Concepts(string pathFileName)
        {
            meta.DeserializeSF1MetaXml(pathFileName);
        }

        public IList<Variable> FetchConcepts()
        {
            VariableList = meta.VariableList;
            
            return VariableList;
        }

        public IList<Variable> FetchConceptsByDescription(string search_string)
        {
            VariableList = meta.VariableList.Where(c => c.Concept.ToUpper().Trim().IndexOf(search_string) >= 0).ToList();

            return VariableList;
        }

    }
}