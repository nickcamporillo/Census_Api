﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;


namespace CensusApi.Entities 
{
	/// <summary>
	/// Summary description for JQueryObject
	/// </summary>

	[DataContract]
	public class JQueryObject:IEntity
	{
		//======= Members ==========
		private string _fips_code = string.Empty;
		private string _query_item_1 = string.Empty;  //Obtained from field "P0010001";
		private string _query_item_2 = string.Empty;
		

		//======= Properties ==========
		[DataMember]
		public string FipsCode
		{
			get { return _fips_code; }
			set { _fips_code = value; }
		}
		
		[DataMember]
		public string QueryItem_01
		{
			get { return _query_item_1; }
			set { _query_item_1 = value; }
		}
		[DataMember]
		public string QueryItem_02
		{
			get { return _query_item_2; }
			set { _query_item_2 = value; }
		}

		//======= Constructors ==========
		public JQueryObject(){}

		public JQueryObject(string query_item_1, string query_item_2, string fips_code)
		{
			_query_item_1 = query_item_1;
			_query_item_2 = query_item_2;
			_fips_code = fips_code;
		}
	}   
}