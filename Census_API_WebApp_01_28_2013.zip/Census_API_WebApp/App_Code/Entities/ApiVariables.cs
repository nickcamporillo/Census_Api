﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;

//http://www.census.gov/developers/data/sf1.xml
//http://stackoverflow.com/questions/364253/how-to-deserialize-xml-document
//http://stackoverflow.com/questions/6696603/c-sharp-xml-element-with-attribute-and-node-value whereby an element had both a value and an attribute

/// <summary>
/// Summary description for ApiVariables (from the Census 2010 SF1 metafile)
/// </summary>
namespace CensusApi.Entities
{
    [Serializable()]    
    [XmlRoot("apivariables")]
    public class ApiVariables
    {
        private List<Concept> _concepts = new List<Concept>();

        [XmlElement("concept")]
        public List<Concept> Concepts
        {
            get { return _concepts; }
            set { _concepts = value; }
        }

        public ApiVariables() { }

    }

    [Serializable()]
    public class Concept
    {
        private List<Variable> _vars = new List<Variable>();
        private string _name = string.Empty;

        [XmlAttribute("name")]
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        
        [XmlElement("variable")]        
        public List<Variable> Variable
        {
            get { return _vars; }
            set { _vars = value; }       
        }
    }

    [Serializable()]
    public class Variable
    {
        private string _name = string.Empty;
        private string _concept = string.Empty;
        private string _text = string.Empty;

        [XmlAttribute("name")]
        public string Name
        {
            set { _name = value; }
            get { return _name; }        
        }

        [XmlAttribute("concept")]
        public string Concept
        {
            set { _concept = value; }
            get { return _concept; }
        }

        [XmlText] //Solution from http://stackoverflow.com/questions/6696603/c-sharp-xml-element-with-attribute-and-node-value whereby an element had both a value and an attribute
        public string Value
        {
            get { return _text; }
            set { _text = value; }
        }
    }
}