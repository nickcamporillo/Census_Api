﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Dataset
/// </summary>
namespace CensusApi.Entities
{
    public class Dataset:IEntity
    {
        private const string API_FIELD_STATECODE = "STATE";
        private const string API_FIELD_COUNTYCODE = "COUNTY";
        private const string API_FIELD_COUNTYNAME = "NAME";

        private Concepts _concs;

        public IList<DataItem> Results { get; set; }
        public int Sum { get; private set; }

        public Dataset() { }

        public Dataset(Concepts concepts)
        {
            _concs = concepts;
        }

        //This method "flattens" a set of key-value pairs from JSON (captured in the IList<Field>) into rows
        public void CreateDataset(IList<Field> fields, int min, int max)
        {
            string current_state = string.Empty;
            string current_county_name = string.Empty;
            string current_county_code = string.Empty;
            string description = string.Empty;

            if (Results == null)
                Results = new List<DataItem>();
            else
                Results.Clear();

            for (int i = fields.Count - 1; i >= 0; i--)
            {
                if (fields[i].Name == API_FIELD_STATECODE)
                {
                    current_state = fields[i].Value;
                }
                else if (fields[i].Name == API_FIELD_COUNTYNAME)
                {
                    current_county_name = fields[i].Value;
                }
                else if (fields[i].Name == API_FIELD_COUNTYCODE)
                {
                    current_county_code = fields[i].Value;
                }
                else if (fields[i].Name != API_FIELD_COUNTYNAME &&
                         fields[i].Name != API_FIELD_STATECODE &&
                         fields[i].Name != API_FIELD_COUNTYCODE &&
                         current_state.Length > 0 &&
                         current_county_name.Length > 0)
                {

                    if (int.Parse(fields[i].Value) >= min && int.Parse(fields[i].Value) <= max)
                    {
                        if (_concs != null && _concs.VariableList != null)
                        {
                            var c = (from Variable conc in _concs.VariableList
                                     where conc.Name == fields[i].Name
                                     select conc.Value).ToList()[0];
                            description = c;
                        }

                        DataItem di = new DataItem { State = current_state, County = current_county_code, CountyName = current_county_name, Dataset = fields[i].Name, Description = description, Value = fields[i].Value };
                        Results.Add(di);
                        Sum = Sum + int.Parse(di.Value);
                    }
                }
            }

            Results.OrderBy(c => c.State).ThenBy(c=>c.CountyName);

        }
    }
}