﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Dataset
/// </summary>
namespace CensusApi.Entities
{
    public class Dataset:IEntity
    {
        private const string API_FIELD_STATECODE = "STATE";
        private const string API_FIELD_COUNTYCODE = "COUNTY";
        private const string API_FIELD_COUNTYNAME = "NAME";

        public IList<DataItem> Results { get; set; }

        //This method "flattens" a set of key-value pairs from JSON (captured in the IList<Field>) into rows
        public void CreateDataset(IList<Field> fields)
        {
            string current_state = string.Empty;
            string current_county_name = string.Empty;
            string current_county_code = string.Empty;

            if (Results == null)
                Results = new List<DataItem>();
            else
                Results.Clear();

            for (int i = fields.Count - 1; i >= 0; i--)
            {

                if (fields[i].Name == API_FIELD_STATECODE)
                {
                    current_state = fields[i].Value;
                }
                else if (fields[i].Name == API_FIELD_COUNTYNAME)
                {
                    current_county_name = fields[i].Value;
                }
                else if (fields[i].Name == API_FIELD_COUNTYCODE)
                {
                    current_county_code = fields[i].Value;
                }
                else if (fields[i].Name != API_FIELD_COUNTYNAME &&
                         fields[i].Name != API_FIELD_STATECODE &&
                         fields[i].Name != API_FIELD_COUNTYCODE &&
                         current_state.Length > 0 &&
                         current_county_name.Length > 0 &&
                         current_county_code.Length > 0)
                {
                    DataItem di = new DataItem { State = current_state, County = current_county_code, CountyName = current_county_name, Dataset = fields[i].Name, Value = fields[i].Value };
                    Results.Add(di);
                }

            }        
        }
    }
}