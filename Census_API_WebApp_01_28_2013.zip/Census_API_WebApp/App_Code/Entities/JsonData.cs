﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using jser = Newtonsoft.Json.Serialization;
using jsu = Newtonsoft.Json.Utilities;
using jarray = Newtonsoft.Json.Linq;

/// <summary>
/// Summary description for JsonMetaInfoEntity
/// </summary>

namespace CensusApi.Entities
{
	public class JsonData : IEntity
	{
		//Contains names of the fields. Since this info is at the top of the JSON result set, this property should be set only once,
		//i.e. during the reading of the top of the JSON result set.  Everything else after that is data. When you look at the
		//both the documentation at http://www.census.gov/developers/, the spot where numeric values begin seem to indicate
		//the end of the field names...so it stands to reason that anything before the numeric values is column names.
		//We should verify this though!!!

        private IList<string> SasDataItemValues { get; set; }

		public IList<string> VariableNames { get; set; }
        public IList<Field> ResultSet { get; set; }

		public JsonData()
		{
			//
			// TODO: Add constructor logic here
			//
		}


        /// <summary>
        ///Gets the field names from the top row of the JSON result set
        /// </summary>
        /// <param name="json_array"></param>
		private void SetColumnNames(jarray.JArray json_array)
		{
			int jint = -9999;
			int cnt = 0;

            //EXIT if there's nothing
            if (json_array.Count == 0)
            {
                return;
            }

			IEnumerable<jarray.JToken> jtoken = json_array.First(c => int.TryParse(c.ToString(), out jint));

			if (jtoken != null)
			{
				VariableNames = new List<string>();
				while (json_array[cnt].ToString() != jint.ToString())
				{
					VariableNames.Add(json_array[cnt].ToString());
					cnt++;
				}
			}			
		}

        private void SetDataItems(jarray.JArray json_array)
		{

            //EXIT if there are no values:
            if (json_array.Count == 0)
            {
                return;            
            }

			if (VariableNames != null && VariableNames.Count > 0)
			{
				SasDataItemValues = new List<string>();
				for (int i = VariableNames.Count; i < json_array.Count; i++)
				{
					SasDataItemValues.Add(json_array[i].ToString());                                                        
				}
			}
		}

        public void PopulateResultSet(jarray.JArray json_array)
        {
            int cnt = 0;            

            SetColumnNames(json_array);
            SetDataItems(json_array);

            ResultSet = new List<Field>();

            while(cnt < SasDataItemValues.Count)
            {
                for (int j = 0; j < VariableNames.Count; j++)
                {
                    ResultSet.Add(new Field { Id = cnt, Name = VariableNames[j], Value = SasDataItemValues[cnt]});
                    cnt++;
                }
            }
        }
	}
}