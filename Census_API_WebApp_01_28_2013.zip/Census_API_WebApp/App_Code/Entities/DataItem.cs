﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DataItem
/// </summary>
namespace CensusApi.Entities
{
    public class DataItem : IEntity
    {
        public string State { get; set; }
        public string County { get; set; }
        public string CountyName { get; set; }
        public string Dataset { get; set; }
        public string Description { get; set; }
        public string Value { get; set; }

    }
}