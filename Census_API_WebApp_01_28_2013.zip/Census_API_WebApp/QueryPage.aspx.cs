﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CensusApi.Entities;
using CensusApi.Utilities;
using json = Newtonsoft.Json;
using jser = Newtonsoft.Json.Serialization;
using jsu = Newtonsoft.Json.Utilities;
using jarray = Newtonsoft.Json.Linq;
using IST.Utilities;

public partial class QueryPage : BasePage
{
    private const string APIVARIABLES_METAFILE = "apivariables.xml";
    private const string FIPS_FILE = "FIPS_CountyName.txt";
    private IList<Field> _result_set = null;


    protected void Page_Load(object sender, EventArgs e)
    {
        btnQueryApi.Click += new EventHandler(SendJsonQuery);
        btnQueryApi.Click += new EventHandler(DisplayResults);
        GetDatasetNames(sender, e);
    }

    protected void GetDatasetNames(object sender, EventArgs e)
    {
        Concepts ah_variables = new Concepts(base.GetDataDirectoryPath() + APIVARIABLES_METAFILE);
        grdAsianHawaiianVariables.DataSource = ah_variables.FetchConcepts();
        grdAsianHawaiianVariables.DataBind();
        lblCount.Text = "Records found: " + ah_variables.Count.ToString();

        GeoItems fips_items = new GeoItems();
        fips_items.ReadFipsFile(base.GetDataDirectoryPath() + FIPS_FILE);
        grdStates.DataSource = fips_items.Items;
        grdStates.DataBind();
    }

    protected void SendJsonQuery(object sender, EventArgs e)
    {
        string query = ApiUtilities.CreateQueryString(txtDataset.Text, txtCounty.Text, txtState.Text);
          
        IConcept concept = new Concepts(base.GetDataDirectoryPath() + APIVARIABLES_METAFILE);
        IList<Variable> concs= concept.FetchConcepts();

        ApiUtilities.ReadJsonQueryResults(base.GetJsonResponseStream(query));

        var concList = concs.Where(c => c.Name == ApiUtilities.Results[0].Name);

        _result_set = ApiUtilities.Results; 
    }

    private void DisplayResults(object sender, EventArgs e)
    {
        base.SetJsonQueryToSession(_result_set);
        Response.Redirect("QueryResults.aspx");
    }

}

///*
///
///TO DO: Merge the Concepts.Concept with the SasDataResults.Field.Name using LINQ/LAMBDA
///
///*