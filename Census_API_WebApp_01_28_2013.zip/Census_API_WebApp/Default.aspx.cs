﻿using System;
using System.Text;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Web.UI;
using System.Web.UI.WebControls;
using json = Newtonsoft.Json;
using jser = Newtonsoft.Json.Serialization;
using jsu = Newtonsoft.Json.Utilities;
using jarray = Newtonsoft.Json.Linq;
using IST.Utilities;
using CensusApi.Utilities;
using CensusApi.Entities;

namespace CensusApi
{

    public partial class _Default : BasePage
    {
    }
    
}