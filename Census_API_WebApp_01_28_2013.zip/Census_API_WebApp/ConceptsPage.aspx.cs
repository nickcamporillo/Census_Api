﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CensusApi.Entities;
using CensusApi.Utilities;
using json = Newtonsoft.Json;
using jser = Newtonsoft.Json.Serialization;
using jsu = Newtonsoft.Json.Utilities;
using jarray = Newtonsoft.Json.Linq;
using IST.Utilities;

public partial class ConceptsPage : BasePage
{
    private const string FIPS_DATA_FILE = "FIPS_CountyName.txt";
    private IList<Variable> results = null;
    private Concepts ah_variables = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        btnSearchByDescription.Click += new EventHandler(GetDescriptionSubset);
        btnReset.Click += new EventHandler(btnReset_Click);
    }

    protected void GetDatasetNames(object sender, EventArgs e)
    {
        ah_variables = new Concepts(base.GetDataDirectoryPath() + CONCEPT_METADATA_FILE);
        results = ah_variables.FetchConcepts();
        PresentResults<Variable>(results);
    }

    protected void GetDescriptionSubset(object sender, EventArgs e)
    {
        ah_variables = new Concepts(base.GetDataDirectoryPath() + CONCEPT_METADATA_FILE);

        if (txtKeyword.Text.Trim() == "*")        
            results = ah_variables.FetchConcepts();                    
        else
            results = ah_variables.VariableList.Where(s => s.Value.ToUpper().IndexOf(txtKeyword.Text.ToUpper()) >= 0).ToList();

        PresentResults<Variable>(results);
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        lblCount.Text = "";
        grdConceptList.DataSource = null;
        grdConceptList.DataBind();
        txtKeyword.Text = "*";
    }

    private void PresentResults<T>(IList<T> results)
    {
        grdConceptList.DataSource = results;
        grdConceptList.DataBind();
        lblCount.Text = "Records found: " + results.Count();            
    }
}

///*
///
///TO DO: Merge the Concepts.Concept with the SasDataResults.Field.Name using LINQ/LAMBDA
///
///*