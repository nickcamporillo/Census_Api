﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using CensusApi.Entities;

public partial class QueryResults : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        IList<Field> f = base.GetJsonQueryFromSession() as IList<Field>;
        IEnumerable<Field> county_name = f.Where(c => c.Name.ToUpper() == "NAME");
        IEnumerable<Field> state_name = f.Where(c => c.Name.ToUpper() == "STATE");
        IEnumerable<Field> county_code = f.Where(c => c.Name.ToUpper() == "COUNTY");
        IEnumerable<Field> datasets = f.Where(c => c.Name.ToUpper() != "NAME" && c.Name.ToUpper() != "STATE" && c.Name.ToUpper() != "COUNTY");

        grdResults.DataSource = null;

        //grdResults.DataSource = base.GetJsonQueryFromSession();
        //grdResults.DataBind();

        string current_state = string.Empty;
        string current_county_name = string.Empty;
        string current_county_code = string.Empty;
        StringBuilder sb = new StringBuilder();
        

        DataItem di = null;
        IList<DataItem> dis = new List<DataItem>();

        for (int i = f.Count - 1; i >= 0; i--)
        {
            string[] dbug = sb.ToString().Split('|');

            if (f[i].Name.ToUpper() == "STATE")
            {
                current_state = f[i].Value.ToUpper();
                sb.Append(current_state + "|");
                if (sb.ToString().Split('|').Count() > 4)
                {
                    dis.Add(di);
                    sb.Length = 0;
                    di = null;
                }
            }
            else if (f[i].Name.ToUpper() == "NAME")
            {
                current_county_name = f[i].Value.ToUpper();
                sb.Append(current_county_name + "|");
                if (sb.ToString().Split('|').Count() > 4)
                {
                    dis.Add(di);
                    sb.Length = 0;
                    di = null;
                }
            }
            else if (f[i].Name.ToUpper() == "COUNTY")
            {
                current_county_code = f[i].Value.ToUpper();
                sb.Append(current_county_code + "|");
                if (sb.ToString().Split('|').Count() > 4)
                {
                    dis.Add(di);
                    sb.Length = 0;
                    di = null;
                }
            }
            else if (f[i].Name.ToUpper() != "NAME" && 
                     f[i].Name.ToUpper() != "STATE" && 
                     f[i].Name.ToUpper() != "COUNTY" && 
                     current_state.Length > 0 && 
                     current_county_name.Length > 0 && 
                     current_county_code.Length > 0 &&
                     sb.ToString().Split('|').Count() <= 4
                )
            {
                Dataset ds = new Dataset { DataSet = f[i].Name, Value = f[i].Value };
                if (di == null)
                    di = new DataItem();
                di.GeoInfo.SetGeoItemInfo(current_state, current_county_name, current_county_code);
                di.Dataset.Add(ds);
            }

        }

        grdResults.DataSource = dis;
        grdResults.DataBind();
    }

}