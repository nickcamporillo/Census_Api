﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Xml.Serialization;
using IST.Utilities;

namespace CensusApi.Entities
{
    /// <summary>
    /// Summary description for Sf1VariableList
    /// </summary>
    public class Sf1VariableList
    {

        private ApiVariables varinfo = new ApiVariables();
        private IList<Variable> vb = new List<Variable>();

        public IList<Variable> VariableList
        {
            get { return vb; }                    
        }

        public Sf1VariableList() 
        {            
        }

        public Sf1VariableList(string pathFilename)
        {
            DeserializeSF1MetaXml(pathFilename);
        }

        public void DeserializeSF1MetaXml(string pathFilename)
        {   
            IST.Utilities.XmlUtility.DeserializeXmlFile<ApiVariables>(ref varinfo, pathFilename);

            for (int i = 0; i < varinfo.Concepts.Count; i++)
            {
                Concept c = varinfo.Concepts[i];
                for (int j = 0; j < c.Variable.Count; j++)
                {
                    vb.Add(c.Variable[j]);                                                        
                }
            }
        }
    }
}