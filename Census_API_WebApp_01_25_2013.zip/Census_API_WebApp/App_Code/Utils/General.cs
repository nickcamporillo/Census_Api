﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using iut = IST.Utilities;

namespace CensusApi.Utilities
{
    /// <summary>
    /// Summary description for General
    /// </summary>
    public static class General
    {
        
    }


    //public class MyFileUtility : IST.BaseClasses.FileUtility
    //{
    //    public static string GetAppPath(SubDirectory dir, string fileName)
    //    {
    //        return string.Format("{0}\\{1}\\{2}", System.AppDomain.CurrentDomain.BaseDirectory, dir.ToString(), fileName);
    //    }
    //    public static string GetAppPath(SubDirectory dir)
    //    {
    //        return string.Format("{0}\\{1}\\", System.AppDomain.CurrentDomain.BaseDirectory, dir.ToString());
    //    }
    //    public static string GetAppPath()
    //    {
    //        return System.AppDomain.CurrentDomain.BaseDirectory;
    //    }
    //}
}