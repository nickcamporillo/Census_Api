﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Xml;

/// <summary>
/// Summary description for CensusApiConfiguration
/// </summary>
public class CensusApiConfiguration : ConfigurationSection
{
    public static CensusApiConfiguration GetConfig()
    {
        return ConfigurationManager.GetSection("censusApiContext/censusApiConfig") as CensusApiConfiguration;
    }

    [ConfigurationProperty("Settings")]
    public ApiSettings Settings
    {
        get { return this["Settings"] as ApiSettings; }    
    }
}

public class ApiSettings : ConfigurationElementCollection
{
    public ApiElement this[int index]
    {
        get { return base.BaseGet(index) as ApiElement; }
        set
        {
            if (base.BaseGet(index) != null)
                base.BaseRemoveAt(index);
            this.BaseAdd(index, value);
        }
    }

    public ApiElement this[string key]
    {
        get { return base.BaseGet(key) as ApiElement; }
    }

    protected override ConfigurationElement CreateNewElement()
    {
        return new ApiElement();
    }
 
    protected override object GetElementKey(ConfigurationElement element)
    {
        return ((ApiElement)element).Name;
    }
}


public class ApiElement : ConfigurationElement
{
    [ConfigurationProperty("name", IsRequired = true)]
    public string Name { get { return this["name"] as string; } }

    [ConfigurationProperty("value", IsRequired = true)]
    public string Value { get { return this["value"] as string; } }
}
